Open inner.zip and keep going.
